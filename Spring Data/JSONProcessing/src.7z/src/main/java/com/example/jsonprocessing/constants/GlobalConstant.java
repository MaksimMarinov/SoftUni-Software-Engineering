package com.example.jsonprocessing.constants;

public class GlobalConstant {
    public static final String RESOURCE_FILE_PATH ="src/main/resources/files/";
}
