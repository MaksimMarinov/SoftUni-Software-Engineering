package com.example.jsonprocessing.Util;

public interface ValidationUtil {
    <E> boolean isValid(E entity);
}
