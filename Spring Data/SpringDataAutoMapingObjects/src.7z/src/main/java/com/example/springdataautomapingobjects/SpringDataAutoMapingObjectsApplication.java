package com.example.springdataautomapingobjects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataAutoMapingObjectsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataAutoMapingObjectsApplication.class, args);
    }

}
