package com.example.springdataautomapingobjects;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataAutoMapingObjectsApplicationTests {

    @Test
    void contextLoads() {
    }

}
