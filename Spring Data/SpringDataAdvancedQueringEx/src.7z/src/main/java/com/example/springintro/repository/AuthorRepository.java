package com.example.springintro.repository;

import com.example.springintro.model.entity.Author;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuthorRepository extends JpaRepository<Author, Long> {

    @Query("SELECT a FROM Author a ORDER BY size(a.books) DESC")
    List<Author> findAllByBooksSizeDESC();

    List<Author> findAllByFirstNameEndingWith(String end);

    @Query("SElECT a FROM Author a\n" +
            "JOIN Book b on a.id = b.author.id\n" +
            "GROUP BY a\n" +
            "ORDER BY SUM(b.copies) DESC")
    List<Author> findAllTotalCopies();
}
