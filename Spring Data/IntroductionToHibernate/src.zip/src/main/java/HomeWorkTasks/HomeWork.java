package HomeWorkTasks;

public interface HomeWork {
    void solveTask();
}
